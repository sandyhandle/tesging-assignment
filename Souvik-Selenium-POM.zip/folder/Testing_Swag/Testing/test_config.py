import sys
sys.path.append("/home/souvik/Desktop/HeroVired/QA/Assignment/UI Testing/folder/Testing_Swag") 

from Config.config import *
from selenium import webdriver


def setUp():
    return webdriver.Chrome(executable_path=Config.CHROME_EXECUTABLE_PATH)

# def getDriver():
#     driver = setUp()
#     driver.get(Config.PROJECT_BASE_URL)