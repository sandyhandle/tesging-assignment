from selenium import webdriver
import time

driver = webdriver.Chrome()

driver.set_window_size(1366,768)

driver.get("https://xndev.com/display-image/")

# file_upload = driver.find_element_by_xpath("<chooseImageXPATH>")
file_upload = driver.find_element_by_xpath('//*[@id="post-2554"]/div/input')

file_upload.send_keys("<ImagePath>")

driver.switch_to_frame()


driver.close()