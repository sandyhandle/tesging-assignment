class Locator:
    XPATH_USERNAME = '//*[@id="user-name"]'
    XPATH_PASSWORD = '//*[@id="password"]'
    XPATH_LOGIN = '//*[@id="login-button"]'