import sys
sys.path.append("/home/i1582/Downloads/Mayank_POM_assignment/Testing_Swag") 

from Config.config import *
from page_object.locator import Locator

class Login:
    def doLogin(self,driver):
        
        username = driver.find_element_by_xpath(Locator.XPATH_USERNAME)
        username.send_keys(Config.USER_NAME)
        password = driver.find_element_by_xpath(Locator.XPATH_PASSWORD)
        password.send_keys(Config.USER_PASSWORD)
        
        login = driver.find_element_by_xpath(Locator.XPATH_LOGIN)
        login.click()
        
        # return driver.current_url