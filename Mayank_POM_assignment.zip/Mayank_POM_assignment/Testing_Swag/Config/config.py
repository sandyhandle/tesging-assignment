class Config:
    CHROME_EXECUTABLE_PATH = "/usr/local/bin/chromedriver"
    PROJECT_BASE_URL = "https://www.saucedemo.com/"

    USER_NAME = "standard_user"
    USER_PASSWORD = "secret_sauce"
    
    LOGIN_TITLE = "Swag Labs"
    
    INVENTRY_URL = "https://www.saucedemo.com/inventory.html"



